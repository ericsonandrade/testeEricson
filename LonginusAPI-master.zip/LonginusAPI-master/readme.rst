API

Posts (OK)
GET (single e index), POST, PUT, DELETE

Categories (OK)
GET (single e index), POST, PUT, DELETE

Category Properties
GET (single e index), POST, DELETE, PUT

Pictures (OK)
PUT, DELETE, CREATE

Users (OK)


